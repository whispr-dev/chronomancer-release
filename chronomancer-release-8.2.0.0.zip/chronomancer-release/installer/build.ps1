#Requires -Version 5.1
<#
.SYNOPSIS
  Builds the Chronomancer MSI and the portable zip, then writes SHA-256 checksums.

.DESCRIPTION
  Output goes to ..\dist\ :
    Chronomancer-<Version>.msi
    whispr.dev-Chronomancer-<Version>-portable.zip
    SHA256SUMS.txt

  Needs the .NET SDK (8 or newer). Installs/pins the WiX command-line tool 6.0.2
  and its UI + Util extensions on first run.

.EXAMPLE
  powershell -ExecutionPolicy Bypass -File .\build.ps1
.EXAMPLE
  powershell -ExecutionPolicy Bypass -File .\build.ps1 -Version 8.2.1.0
#>
[CmdletBinding()]
param(
    [ValidatePattern('^\d+\.\d+\.\d+\.\d+$')]
    [string]$Version = '8.2.0.0',
    [string]$PayloadDir = (Join-Path $PSScriptRoot '..\payload'),
    [string]$OutDir = (Join-Path $PSScriptRoot '..\dist')
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

$WixVersion = '6.0.2'
$Extensions = @('WixToolset.UI.wixext', 'WixToolset.Util.wixext')

function Step([string]$msg) { Write-Host "`n==> $msg" -ForegroundColor Cyan }

# ---------- 1. Version sanity (MSI limits: 255.255.65535; only first 3 fields count) ----------
$parts = $Version.Split('.') | ForEach-Object { [int]$_ }
if ($parts[0] -gt 255 -or $parts[1] -gt 255 -or $parts[2] -gt 65535) {
    throw "Version $Version is out of MSI range (max 255.255.65535.x)."
}

# ---------- 2. Payload present? ----------
Step 'Checking payload'
$PayloadDir = (Resolve-Path $PayloadDir).Path
$required = 'Chronomancer.exe', 'Chronomancer-Wallpaper.png', 'Chronomancer.ico', 'README.md', 'LICENSE.txt'
foreach ($f in $required) {
    if (-not (Test-Path (Join-Path $PayloadDir $f))) { throw "Missing payload file: $PayloadDir\$f" }
}
$exeVer = (Get-Item (Join-Path $PayloadDir 'Chronomancer.exe')).VersionInfo.FileVersion
if ($exeVer -ne $Version) {
    Write-Warning "Chronomancer.exe reports FileVersion '$exeVer' but you're packaging '$Version'. Make sure this is the right exe."
}

# ---------- 3. .NET SDK ----------
Step 'Checking .NET SDK'
if (-not (Get-Command dotnet -ErrorAction SilentlyContinue)) {
    throw "The .NET SDK isn't installed. Run:  winget install --id Microsoft.DotNet.SDK.8 -e   then open a NEW PowerShell window and run this script again."
}
$sdks = & dotnet --list-sdks
if (-not $sdks) {
    throw "dotnet is present but no SDK is installed (runtime only). Run:  winget install --id Microsoft.DotNet.SDK.8 -e"
}

# ---------- 4. WiX tool, pinned ----------
Step "Ensuring WiX $WixVersion"
$wix = Join-Path $env:USERPROFILE '.dotnet\tools\wix.exe'
$installed = $null
if (Test-Path $wix) {
    $installed = ((& $wix --version) -split '\+')[0].Trim()
}
if ($installed -ne $WixVersion) {
    if ($installed) {
        Write-Host "Found WiX $installed - replacing with $WixVersion"
        & dotnet tool uninstall --global wix | Out-Null
    }
    & dotnet tool install --global wix --version $WixVersion
    if ($LASTEXITCODE -ne 0) { throw 'dotnet tool install wix failed.' }
}
Write-Host "WiX: $((& $wix --version))"

# ---------- 5. Extensions, pinned ----------
$extList = (& $wix extension list --global) -join "`n"
foreach ($ext in $Extensions) {
    if ($extList -notmatch [regex]::Escape("$ext $WixVersion")) {
        & $wix extension add --global "$ext/$WixVersion"
    }
}
$extList = (& $wix extension list --global) -join "`n"
foreach ($ext in $Extensions) {
    if ($extList -notmatch [regex]::Escape("$ext $WixVersion")) {
        throw "WiX extension $ext $WixVersion isn't in the global cache. Try:  wix extension add --global $ext/$WixVersion"
    }
}

# ---------- 6. Build MSI ----------
Step "Building MSI $Version"
New-Item -ItemType Directory -Force -Path $OutDir | Out-Null
$OutDir = (Resolve-Path $OutDir).Path
$msi = Join-Path $OutDir "Chronomancer-$Version.msi"
if (Test-Path $msi) { Remove-Item $msi -Force }

Push-Location $PSScriptRoot
try {
    $wixArgs = @(
        'build', (Join-Path $PSScriptRoot 'Chronomancer.wxs'),
        '-arch', 'x64',
        '-culture', 'en-US',
        '-d', "ProductVersion=$Version",
        '-d', "PayloadDir=$PayloadDir",
        '-bindpath', $PSScriptRoot,
        '-o', $msi
    )
    foreach ($ext in $Extensions) { $wixArgs += @('-ext', $ext) }
    & $wix @wixArgs
    if ($LASTEXITCODE -ne 0) { throw "wix build failed (exit $LASTEXITCODE)." }
}
finally {
    Pop-Location
}
# wix also drops a .wixpdb (debug symbols) next to the MSI; keep it out of the release folder
Get-ChildItem $OutDir -Filter '*.wixpdb' | Remove-Item -Force

# ---------- 7. Portable zip ----------
Step 'Building portable zip'
$zip = Join-Path $OutDir "whispr.dev-Chronomancer-$Version-portable.zip"
if (Test-Path $zip) { Remove-Item $zip -Force }
$zipItems = 'Chronomancer.exe', 'Chronomancer-Wallpaper.png', 'README.md', 'LICENSE.txt' |
    ForEach-Object { Join-Path $PayloadDir $_ }
Compress-Archive -Path $zipItems -DestinationPath $zip -CompressionLevel Optimal

# ---------- 8. Checksums ----------
Step 'Writing SHA256SUMS.txt'
$sums = foreach ($f in @($msi, $zip)) {
    $h = (Get-FileHash $f -Algorithm SHA256).Hash.ToLower()
    "$h  $(Split-Path $f -Leaf)"
}
$utf8NoBom = New-Object System.Text.UTF8Encoding $false
[IO.File]::WriteAllText((Join-Path $OutDir 'SHA256SUMS.txt'), (($sums -join "`n") + "`n"), $utf8NoBom)

Step 'Done'
Get-ChildItem $OutDir | Format-Table Name, @{n = 'MB'; e = { '{0:N1}' -f ($_.Length / 1MB) } } -AutoSize
$sums | ForEach-Object { Write-Host $_ }
Write-Host "`nTest it:  msiexec /i `"$msi`" /l*v `"$env:TEMP\chronomancer-install.log`""
